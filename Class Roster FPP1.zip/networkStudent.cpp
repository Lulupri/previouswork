#include "networkStudent.h"


Degree networkStudent::getdegreeType() {
    return NETWORK;
}