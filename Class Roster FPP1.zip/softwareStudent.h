#ifndef  SOFTWARESTUDENT_H
#define SOFTWARESTUDENT_H

#include <iostream>
#include "Student.h"
#include "Degree.h"
#include <string>

using namespace std;

class softwareStudent : public Student //child class
{
public:
    using Student::Student;
    Degree getdegreeType();

private:
    Degree degree = SOFTWARE;
};

#endif