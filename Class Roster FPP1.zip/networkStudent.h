#ifndef NETWORKSTUDENT_H
#define NETWORKSTUDENT_H
#include <iostream>
#include "Student.h"
#include "Degree.h"




class networkStudent : public Student {
public:
    using Student::Student;
    Degree getdegreeType();

private:
    Degree degree = NETWORK;
};
#endif
