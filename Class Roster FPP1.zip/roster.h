#ifndef ROSTER_H
#define ROSTER_H

#include <iostream>
#include <string>
#include "Student.h"
#include "softwareStudent.h"
#include "securityStudent.h"
#include "networkStudent.h"
#include "Degree.h"

using namespace std;



class roster
{

public:

	Student* classRosterArray[6] = { nullptr, nullptr, nullptr, nullptr, nullptr };


	//roster(int dataSize);
	void add(string studentID, string firstName, string lastName, string emailAddress, int age, int, int, int, Degree program);
	void remove(string stdID);
	void printAll();
	void printByDegree(Degree degreeType);
	void printInvalidEmails();
	void printAverageDaysInCourse(string stdID);
	~roster();

	
};


#endif // !ROSTER_H

