#ifndef SECURITYSTUDENT_H
#define SECURITYSTUDENT_H

#include "Student.h"
#include "Degree.h"


class securityStudent : public Student //child class
{
    using Student::Student;
    Degree getdegreeType();

private:
    Degree degree = SECURITY;
};
#endif