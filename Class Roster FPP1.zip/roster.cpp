#include <stdarg.h>
#include <iostream>
#include <vector>
#include <stdexcept>
#include "roster.h"
#include <cmath>
#include "Student.h"
#include <string>
#include <sstream>
#include "Degree.h"


using namespace std;



void roster::add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, Degree program) {
	
	int days[3] = { daysInCourse1, daysInCourse2, daysInCourse3 };

	for (int i = 0; i < 5; i++) {
		if (classRosterArray[i] == nullptr) {
			if (program == SECURITY) {
				classRosterArray[i] = new securityStudent(studentID, firstName, lastName, emailAddress, age, days, program);
			}
			else if (program == NETWORK) {
				classRosterArray[i] = new networkStudent(studentID, firstName, lastName, emailAddress, age,days, program);
			}
			else if(program == SOFTWARE) {
				classRosterArray[i] = new softwareStudent(studentID, firstName, lastName, emailAddress, age, days, program);
			}

			break;
		}
	}
}
void roster::remove(string stdID)
{
	int i = 0;
	bool found = false;

	while (i < 5) {

		if (classRosterArray[i] != nullptr && classRosterArray[i]->getStdID() == stdID) {

			classRosterArray[i] = nullptr;

			found = true;

			break;
		}

		i++;
	}
	if (found == false) {
		cout << "Error: Student not found." << endl;
	}
}



void roster::printAll()
{

	for (int i = 0; i < 5; i++) {

		if (classRosterArray[i] != nullptr) {
			classRosterArray[i]->print();
		}

	
	}
}




void roster::printByDegree(Degree )
{
	
	
	cout << "Types of degrees: " << "Network, Software, Security " << endl;
	for (int i = 0; i < 5; i++)
	{
		Student* student = classRosterArray[i];
		if (this->classRosterArray[i]->getdegreeType() == Degree())  this->classRosterArray[i]->print();

	}


}

void roster::printInvalidEmails()
{

	for (int i = 0; i < 5; i++) {
		Student* student = classRosterArray[i];
		string email = student->getEmail();
		bool foundError = false;

		if (email.find('@') == string::npos) {
			foundError = true;
		}

		if (email.find('.') == string::npos) {
			foundError = true;
		}

		if (email.find(' ') != string::npos) {
			foundError = true;
		}

		if (foundError == true) {
			cout << email << endl;
		}

	}

}

void roster::printAverageDaysInCourse(string stdID)
{

	for (int i = 0; i < 5; i++) {
		if (classRosterArray[i] != nullptr && classRosterArray[i]->getStdID() == stdID) {
			int* daysToAvg = classRosterArray[i]->getDays();
			float sumOfDays = 0.0;

			for (int i = 0; i < 3; i++) {
				sumOfDays += daysToAvg[i];
			}

			cout << (sumOfDays / 3) << endl;
		}

	
	}

}

int main()
{
	
	roster *classRoster = new roster();


	const string studentData[5] =
	{ "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
		"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
		"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
		"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
		"A5,Adrianna,Allen,aall386@my.wgu.edu,23,30,45,50, SOFTWARE"
	};

	for (int i = 0; i < 5; i++) {
		stringstream ss(studentData[i]);
		vector<string> input;

		while (ss.good()) {
			string substr;
			getline(ss, substr, ',');
			input.push_back(substr);
		}

		Degree degree;
		string studentDegree = input.at(9);

		if (studentDegree == "SECURITY") {
			degree = SECURITY;
		}
		else if (studentDegree == "NETWORK") {
			degree = NETWORK;
		}
		else {
			degree = SOFTWARE;

			for (int i = 0; i < 5; i++)
			{
				classRoster->add(input.at(0), input.at(1), input.at(2), input.at(3), stoi(input.at(4)), stoi(input.at(5)), stoi(input.at(6)), stoi(input.at(7)), degree);
			}
		}
		//catch( std::studentDegree& oor)
		// It will generate an out-of-range error with degree. I am unsure how to prevent this with a throw exception for a enum. 
	}
	
		cout << "Student Roster" << endl;
		classRoster->printAll();
		cout << endl;

		for (int i = 0; i < 5; i++) {
			classRoster->printAverageDaysInCourse(classRoster->classRosterArray[i]->getStdID());
		}

		cout << endl;

		classRoster->printByDegree(Degree::SOFTWARE);

		cout << endl;

		classRoster->remove("A3");
		classRoster->remove("A3");


		system("pause");
		return 0;
	
}

roster::~roster()

{
	for (int i = 0; i < 5; i++)
	{
		delete this->classRosterArray[i];
	}
}

