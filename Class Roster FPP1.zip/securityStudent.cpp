#include "securityStudent.h"

Degree securityStudent::getdegreeType() {
    return SECURITY;
}

