#ifndef  DEGREE_H
#define DEGREE_H


enum Degree { SECURITY, NETWORK, SOFTWARE };
#endif // ! DEGREE_H