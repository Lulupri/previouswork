#include <iostream>
#include <string>
#include "Student.h"
#include "Degree.h"


using namespace std;


Student::Student(string sID, string stdF, string stdL, string stdE, int sAge, int daysDone[3], Degree degreeType)
{

	this->student_ID = sID;
	this->firstName = stdF;
	this->lastName = stdL;
	this->email = stdE;
	this->age = sAge;
	this->days = daysDone;
	this->degreeType = degreeType;
}

void Student::setStdID(string sID)
{
	this->student_ID = sID;
}

string Student::getStdID()
{
	return student_ID;
}

void Student::setFName(string stdF)
{
	this->firstName = stdF;
}
string Student::getFName()
{
	return firstName;
}
void Student::setLName(string stdL)
{
	this->lastName = stdL;
}
string Student::getLName()
{
	return lastName;
}
void Student::setEmail(string stdE)
{
	this->email = stdE;
}
string Student::getEmail()
{
	return email;
}
void Student::setAge(int stdAge)
{
	this->age = stdAge;
}
int Student::getAge()
{
	return age;
}
void Student::setDays(int dayDone[3])
{
	for (int i = 0; i < 3; i++)
		days[i] = dayDone[i];

}
int* Student::getDays()
{
	return days;
}

Degree Student::getdegreeType()
{
	return degreeType;

}

void Student::setdegreeType(Degree degreeType)
{
	this->degreeType = degreeType;
}

void Student::print()
{

	string degree;

	if (this->degreeType == Degree::SECURITY) {
		degree = "Security";
	}
	else if (this->degreeType == Degree::NETWORK) {
		degree = "Network";
	}
	else if (this->degreeType == Degree::SOFTWARE) {
		degree = "Software";
	}

	cout << "StudentID: " << getStdID() << "\t";
	cout << "First Name: " << getFName() << "\t";
	cout << "Last Name: " << getLName() << "\t";
	cout << "Email Address: " << getEmail() << "\t";
	cout << "Age: " << getAge() << "\t";
	cout << "Days in Courses: " << getDays()[0] << getDays()[1] << getDays()[2] << getDays()[3] << "\t";
	cout << "Degree Type: " << degree << endl;
}

Student::~Student()
{

}
