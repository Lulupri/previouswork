
#include "softwareStudent.h"



Degree softwareStudent::getdegreeType() {
    return Degree::SOFTWARE;
}