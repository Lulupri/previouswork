#pragma once
#include <iostream>
#include "Degree.h"
#include <string>

using namespace std;

class Student // Parent Class
{



private:
	string student_ID;
	string firstName;
	string lastName;
	string email;
	int age;
	int* days;
	Degree degreeType;

public:	
	
	
	Student(string, string, string, string, int, int[3], Degree);//defines all 
	void setStdID(string);
	string getStdID();
	void setFName(string);
	string getFName();
	void setLName(string);
	string getLName();
	void setEmail(string);
	string getEmail();
	void setAge(int);
	int getAge();
	void setDays(int[3]);
	int* getDays();
	virtual Degree getdegreeType() = 0; //grabs degree here
	virtual void setdegreeType(Degree degreeType);
	virtual void print();

	~Student();
};
